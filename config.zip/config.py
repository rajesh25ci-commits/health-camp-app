"""
Configuration settings for the Smart Community Health Camp Management System.
Handles environment-based configurations, database URI, file upload paths,
and session management settings.
"""

import os

# Base directory of the project
BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    """Base application configuration."""

    # Cryptographic secret key for session management & CSRF protection
    SECRET_KEY = os.environ.get('SECRET_KEY', 'smart-health-camp-super-secret-key-2026-production')

    # SQLite Database URI configuration
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'DATABASE_URL',
        f"sqlite:///{os.path.join(BASE_DIR, 'database.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Uploads and QR Code storage configuration
    STATIC_FOLDER = os.path.join(BASE_DIR, 'static')
    UPLOAD_FOLDER = os.path.join(STATIC_FOLDER, 'uploads')
    QRCODE_FOLDER = os.path.join(STATIC_FOLDER, 'qrcodes')

    # Maximum upload payload size: 16 MB (16 * 1024 * 1024 bytes)
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024

    # Allowed image file extensions for uploads
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp'}
